/*
 * Copyright 2014-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.dbflute.bhv.core;

import javax.sql.DataSource;

import org.dbflute.dbmeta.DBMetaProvider;
import org.dbflute.jdbc.StatementFactory;
import org.dbflute.s2dao.jdbc.TnResultSetHandlerFactory;
import org.dbflute.s2dao.metadata.TnBeanMetaDataFactory;

/**
 * @author jflute
 */
public interface BehaviorCommandComponentSetup {

    void setDBMetaProvider(DBMetaProvider dbmetaProvider);

    void setDataSource(DataSource dataSource);

    void setStatementFactory(StatementFactory statementFactory);

    void setBeanMetaDataFactory(TnBeanMetaDataFactory beanMetaDataFactory);

    void setResultSetHandlerFactory(TnResultSetHandlerFactory resultSetHandlerFactory);

    void setSqlFileEncoding(String sqlFileEncoding);
}
