/*
 * Copyright 2014-2026 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.dbflute.immutable;

/**
 * The interface of DB-able entity, used when immutable handling is available. <br>
 * The word 'DB-able' means entity that can be DBFlute handling.
 * @param <IMMU> The type of immutable entity corresponding the DB-able entity.
 * @author jflute
 * @since 1.0.5J (2014/06/15 Sunday)
 */
public interface DBableEntity<IMMU> {

    /**
     * Accept immutable entity to initialize this.
     * @param immu The immutable entity to be accepted. (NotNull)
     * @return this. (NotNull)
     */
    DBableEntity<IMMU> acceptImmutable(IMMU immu);

    /**
     * Convert DB-able entity to immutable entity.
     * @return The immutable entity toe be converted. (NotNull)
     */
    IMMU toImmutable();
}
